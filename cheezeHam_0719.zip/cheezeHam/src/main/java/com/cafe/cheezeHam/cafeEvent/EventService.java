package com.cafe.cheezeHam.cafeEvent;

import com.cafe.cheezeHam.cafeUser.CafeUser;
import com.sbb.demo.DataNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventService {

    private  final EventCommentRepository eventCommentRepository;
    private final EventRepository eventRepository;

    public void create(String title, /*MultipartFile file,*/ String content, CafeUser user) throws IOException {
        Event event = new Event();

        event.setTitle(title);

       /* if (file != null) {
            if (!file.isEmpty()) {
                byte[] fileBytes = file.getBytes();
                event.setFile(fileBytes); // 파일 바이트 배열 저장 or 파일 경로 저장
            } else {
                // 파일이 비어있는 경우 처리할 로직을 추가합니다.
                // 예를 들어, 기본 파일을 설정하거나, 경고 메시지를 출력하거나, 특정 처리를 수행할 수 있습니다.
                event.setFile(new byte[0]); // 빈 파일 데이터를 설정하는 예시
            }
        } else {
            // file이 null일 때의 처리 로직을 추가합니다.
            // 예를 들어, 기본 파일을 설정하거나, 경고 메시지를 출력하거나, 예외를 던지거나, 특정 처리를 수행할 수 있습니다.
            event.setFile(new byte[0]); // 빈 파일 데이터를 설정하는 예시
        }*/

        event.setContent(content);
        event.setReg_date(LocalDateTime.now());
        event.setAuthor(user);

        this.eventRepository.save(event);
    }

    public Page<Event> getEvents(int page, String keyword, int pageSize){
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("reg_date"));
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sorts));

        return this.eventRepository.findAllByKeyword(keyword, pageable);
    }

    @Transactional
    public void increaseViewCount(int no) {

        eventRepository.increaseViewCount(no);
    }

    public Event getEvent(Integer no) {
        List<Event> eventList = this.eventRepository.findByNo(no);
        if (eventList != null && !eventList.isEmpty()) {
            return eventList.get(0);
        } else {
            throw new DataNotFoundException("Event not found for no: " + no);
        }
    }

    public void getEventComment(Event event, String content, CafeUser user){
        EventComment eventComment = new EventComment();
        eventComment.setEvent(event);
        eventComment.setContent(content);
        eventComment.setRegDate(LocalDateTime.now());
        eventComment.setCafeUser(user);

        this.eventCommentRepository.save(eventComment);
    }




}
