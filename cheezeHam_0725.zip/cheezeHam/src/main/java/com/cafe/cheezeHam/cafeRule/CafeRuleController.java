package com.cafe.cheezeHam.cafeRule;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
@RequestMapping("/cafeRule")
public class CafeRuleController {

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/rulePage")
    public String CafeRuler(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if (username != null) {
                model.addAttribute("username", username);
            }
        }
        return "cafeRule/cafe_rule";
    }
}
