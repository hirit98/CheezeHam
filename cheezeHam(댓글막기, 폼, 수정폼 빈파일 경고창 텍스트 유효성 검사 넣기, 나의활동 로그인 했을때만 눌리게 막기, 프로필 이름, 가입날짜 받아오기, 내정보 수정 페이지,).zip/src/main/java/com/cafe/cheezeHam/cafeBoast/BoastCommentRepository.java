package com.cafe.cheezeHam.cafeBoast;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BoastCommentRepository extends JpaRepository<BoastComment, Integer> {
    @Query("select bc from BoastComment bc where bc.boast.no = :no order by bc.regDate desc ")
    List<BoastComment> findAllById(@Param("no") int no);


    @Query("select bc from BoastComment bc where bc.boast.no = :no order by bc.regDate asc")
    List<BoastComment> findAllByNoOrderByRegDateAsc(@Param("no") int no);

    @Query("select bc from BoastComment bc where bc.boast.no = :no order by bc.regDate desc")
    List<BoastComment> findAllByNoOrderByRegDateDesc(@Param("no") int no);

    @Query("SELECT COUNT(bc) FROM BoastComment bc WHERE bc.cafeUser.username = :username")
    long countByAuthorUsername(@Param("username") String username);
}
