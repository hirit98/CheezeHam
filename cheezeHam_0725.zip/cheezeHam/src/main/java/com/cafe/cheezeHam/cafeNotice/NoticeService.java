package com.cafe.cheezeHam.cafeNotice;

import com.cafe.cheezeHam.cafeUser.CafeUser;
import com.sbb.demo.DataNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository noticeRepository;
    private final NoticeCommentRepository noticeCommentRepository;

    public void create(String title, String content, String file, CafeUser user) {
        Notice notice = new Notice();
        notice.setTitle(title);
        notice.setContent(content);
        notice.setType("notice");
        notice.setReg_date(LocalDateTime.now());
        notice.setAuthor(user);
        notice.setFile_path(file);

        this.noticeRepository.save(notice);
    }

    public void createImportant(String title, String content, String file, CafeUser user) {
        Notice notice = new Notice();
        notice.setTitle(title);
        notice.setContent(content);
        notice.setType("important");
        notice.setReg_date(LocalDateTime.now());
        notice.setAuthor(user);
        notice.setFile_path(file);

        this.noticeRepository.save(notice);
    }

    public Page<Notice> getNotices(int page, int pageSize, int field, String keyword) {
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("reg_date"));
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sorts));
        if(field == 1) {
            return this.noticeRepository.findTitleByKeyword(keyword, pageable);
        } else if (field == 2) {
            return this.noticeRepository.findAuthorByKeyword(keyword, pageable);
        } else if (field == 3) {
            return this.noticeRepository.findTitleAndContentByKeyword(keyword, pageable);
        }
        return this.noticeRepository.findAllByKeyword(keyword, pageable);
    }
    
    @Transactional
    public void increaseViewCount(int no) {
        noticeRepository.increaseViewCount(no);
    }

    public Notice getNotice(int no) {
        Optional<Notice> notice = this.noticeRepository.findById(no);
        if(notice.isPresent()) {
            return notice.get();
        } else {
            throw new DataNotFoundException("Notice not found for no: " + no);
        }
    }

    public void createNoticeComment(Notice notice, String content, CafeUser user) {
        NoticeComment noticeComment = new NoticeComment();
        noticeComment.setContent(content);
        noticeComment.setNotice(notice);
        noticeComment.setRegDate(LocalDateTime.now());
        noticeComment.setCafeUser(user);

        this.noticeCommentRepository.save(noticeComment);
    }

    public void noticeModify(Notice notice, String title, String content) {
        notice.setTitle(title);
        notice.setContent(content);
        notice.setUpdate_date(LocalDateTime.now());

        this.noticeRepository.save(notice);
    }

    public void noticeDelete(Notice notice) {this.noticeRepository.delete(notice);}

    public NoticeComment getNoticeComment(int no) {
        Optional<NoticeComment> noticeComment = this.noticeCommentRepository.findById(no);
        if(noticeComment.isPresent()) {
            return noticeComment.get();
        } else {
            throw new DataNotFoundException("NoticeComment not found for no: " + no);
        }
    }

    public void noticeCommentModify(NoticeComment noticeComment, String content) {
        noticeComment.setContent(content);
        noticeComment.setUpDate(LocalDateTime.now());
        this.noticeCommentRepository.save(noticeComment);
    }

    public void noticeCommentDelete(NoticeComment noticeComment) {this.noticeCommentRepository.delete(noticeComment);}

    public boolean hasNotice(int no) {
        Optional<Notice> notice = this.noticeRepository.findById(no);
        return notice.isPresent();
    }

    public void addVote(Notice notice, CafeUser user) {
        notice.getVoter().add(user);
        this.noticeRepository.save(notice);
    }

    public void removeVote(Notice notice, CafeUser user) {
        notice.getVoter().remove(user);
        this.noticeRepository.save(notice);
    }

    public boolean isChecked(Notice notice, CafeUser user) {
        return notice.getVoter().contains(user);
    }

    public int getMaxNo() {return this.noticeRepository.findMaxNo();}

}
