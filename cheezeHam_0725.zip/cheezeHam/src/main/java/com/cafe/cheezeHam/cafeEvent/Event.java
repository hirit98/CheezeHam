package com.cafe.cheezeHam.cafeEvent;


import com.cafe.cheezeHam.cafeUser.CafeUser;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Data
@Entity
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no;

    @Column(length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String content;

    @ManyToOne
    private CafeUser author;

    private LocalDateTime reg_date;

    private LocalDateTime update_date;

    @OneToMany(mappedBy = "event", cascade = CascadeType.REMOVE)
    private List<EventComment> commentList;

    @Column(columnDefinition = "INT DEFAULT 0")
    private  int hit;

    private String file_path;

    @ManyToMany
    Set<CafeUser> voter;

}
