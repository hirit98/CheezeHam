 $(document).ready(function() {
        $(".aside_admin_profil").css({ zIndex: "2" });
        $(".aside_tab_btn_cafe_info").css({ fontWeight: "600", color: "black" });

        $(".aside_tab_btn_cafe_info").click(function() {
            $(".aside_admin_profil").css({ zIndex: "2" });
            $(".aside_user_profil").css({ zIndex: "-1" });
             $(".aside_tab_btn_cafe_info").css({ fontWeight: "600", color: "black" });
             $(".aside_tab_btn_my_info").css({ fontWeight: "100", color: "#333" });
        });

        $(".aside_tab_btn_my_info").click(function() {
            $(".aside_admin_profil").css({ zIndex: "-1" });
            $(".aside_user_profil").css({ zIndex: "2" });
            $(".aside_tab_btn_cafe_info").css({ fontWeight: "100", color: "#333" });
            $(".aside_tab_btn_my_info").css({ fontWeight: "600", color: "black" });
        });
    });