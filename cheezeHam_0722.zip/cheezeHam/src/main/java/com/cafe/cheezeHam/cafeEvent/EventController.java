package com.cafe.cheezeHam.cafeEvent;

import com.cafe.cheezeHam.cafeNotice.Notice;
import com.cafe.cheezeHam.cafeNotice.NoticeRepository;
import com.cafe.cheezeHam.cafeUser.CafeUser;
import com.cafe.cheezeHam.cafeUser.CafeUserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/event")
public class EventController {

    private final EventRepository eventRepository;

    private final EventCommentRepository eventCommentRepository;

    private final NoticeRepository noticeRepository;

    private final EventService eventService;

    private final CafeUserService cafeUserService;

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/create")
    public String eventCreate(HttpServletRequest request, EventForm eventForm, Model model) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if (username != null) {
                model.addAttribute("username", username);
            }
        }
        return "cafeEvent/event_form";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/create")
    public String eventCreate(@Valid EventForm eventForm, BindingResult bindingResult, Principal principal) throws IOException {
        if (bindingResult.hasErrors()) {
            return "cafeEvent/event_form";
        }
        CafeUser user = this.cafeUserService.getUser(principal.getName());

        /*      MultipartFile file = eventForm.getFile();*/

        this.eventService.create(eventForm.getTitle(), eventForm.getContent(), user);
        return "redirect:/event/list";
    }
/*
    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/detail/{no}")
    public String detail(Model model, @PathVariable("no") Integer no) {
        return "/cafeEvent/event_detail";
    }*/

    @GetMapping("/list")
    public String eventList(HttpServletRequest request, Model model, @RequestParam(value="page", defaultValue="0") int page, @RequestParam(value = "keyword", defaultValue = "") String keyword,
                            @RequestParam(value = "pageSize", defaultValue = "15") int pageSize, @RequestParam(value = "hiddenNotice", defaultValue = "false") boolean hiddenNotice, @RequestParam(value = "field", defaultValue = "0") int field) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if(username != null){
                model.addAttribute("username", username);
            }
        }

        List<Notice> importantNotice = noticeRepository.findImportantNoticeList();
        Page<Event> paging = this.eventService.getEvents(page, pageSize, field, keyword);

        model.addAttribute("field", field);
        model.addAttribute("keyword", keyword);
        model.addAttribute("hiddenNotice", hiddenNotice);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("paging", paging);
        model.addAttribute("importantNotice", importantNotice);
        return "cafeEvent/event_list";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/detail/{no}")
    public String detail(HttpServletRequest request,Model model, @PathVariable("no") Integer no, Principal principal) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if(username != null){
                model.addAttribute("username", username);
            }
        }

        // 이벤트 조회 및 조회수 증가
        eventService.increaseViewCount(no);
        Event event = eventService.getEvent(no);
        model.addAttribute("event", event);
        return "cafeEvent/event_detail";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/comment/create/{no}")
    public String createComment(@PathVariable("no") Integer no,@RequestParam(value="content") String content, Principal principal){
        CafeUser user = this.cafeUserService.getUser(principal.getName());

        Event event = this.eventService.getEvent(no);
        this.eventService.createEventComment(event, content, user);

        return String.format("redirect:/event/detail/%s", no);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/modify/{no}")
    public String eventModify(EventForm eventForm, @PathVariable("no") int no, Principal principal){

        Event event = this.eventService.getEvent(no);
        if(!event.getAuthor().getId().equals(principal.getName())){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        eventForm.setContent(event.getContent());
        eventForm.setTitle(event.getTitle());
        return "/cafeEvent/event_form";
    }
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/modify/{no}")
    public String eventModify(@Valid EventForm eventForm, BindingResult bindingResult, Principal principal, @PathVariable("no") int no){
        if(bindingResult.hasErrors()){
            return"/cafeEvent/event_form";
        }
        Event event = this.eventService.getEvent(no);
        if(!event.getAuthor().getId().equals(principal.getName())){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        this.eventService.eventModify(event, eventForm.getTitle(), eventForm.getContent());
        return String.format("redirect:/event/detail/%s", no);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/delete/{no}")
    public String eventDelete(Principal principal, @PathVariable("no") int no) {
        Event event = this.eventService.getEvent(no);
        if(!event.getAuthor().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
        }
        this.eventService.eventDelete(event);
        return "redirect:/event/list";
    }
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/comment/modify/{no}")
    public String eventReplyModify(EventCommentForm eventCommentForm, @PathVariable("no") int no, Principal principal) {
        EventComment eventComment = this.eventService.getEventComment(no);
        if (!eventComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        eventComment.setContent(eventComment.getContent());
        return "/cafeEvent/reply_modify_form";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/comment/modify/{no}")
    public String eventReplyModify(@Valid EventCommentForm eventCommentForm, @PathVariable("no") Integer no, Principal principal) {
        EventComment eventComment = this.eventService.getEventComment(no);
        if (!eventComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        this.eventService.eventReplyModify(eventComment, eventCommentForm.getContent());
        return String.format("redirect:/event/detail/%s", eventComment.getEvent().getNo());
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/comment/delete/{no}")
    public String eventReplyDelete(Principal principal, @PathVariable("no") int no) {
        EventComment eventComment = this.eventService.getEventComment(no);
        if (!eventComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
        }
        this.eventService.eventReplyDelete(eventComment);
        return String.format("redirect:/event/detail/%s", eventComment.getEvent().getNo());
    }
}
