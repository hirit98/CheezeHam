package com.cafe.cheezeHam.cafeUser;

import com.sbb.demo.DataNotFoundException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CafeUserService {
    private final CafeUserRepository cafeUserRepository;

    public CafeUser create(CafeUser user){
        this.cafeUserRepository.save(user);
        return user;
    }

    public void createADMIN(CafeUser user){this.cafeUserRepository.save(user);}

    public CafeUser getUser(String id) {
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByid(id);
        if(cafeUser.isPresent()) {
            return cafeUser.get();
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }

    public CafeUser getUserByNo(int no) {
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByno(no);
        if(cafeUser.isPresent()) {
            return cafeUser.get();
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }

    public void deleteCafeUser(String id){
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByid(id);
        if(cafeUser.isPresent()) {
            this.cafeUserRepository.delete(cafeUser.get());
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }

    public Page<CafeUser> getAllUsers(int page, int pageSize, String keyword){
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("no"));
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sorts));
        return this.cafeUserRepository.findUserBykeyword(keyword, pageable);
    }

    public Page<CafeUser> getCafeUsers(int page, int pageSize, String keyword){
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("no"));
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sorts));
        return this.cafeUserRepository.findRoleBykeyword(keyword, pageable);
    }

    public Page<CafeUser> getCafeAdmin(int page, int pageSize, String keyword){
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("no"));
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sorts));
        return this.cafeUserRepository.findAdminBykeyword(keyword, pageable);
    }
}
