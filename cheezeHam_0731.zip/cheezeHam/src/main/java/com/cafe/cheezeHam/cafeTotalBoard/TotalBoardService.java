package com.cafe.cheezeHam.cafeTotalBoard;

import com.cafe.cheezeHam.cafeEvent.Event;
import com.cafe.cheezeHam.cafeEvent.EventRepository;
import com.cafe.cheezeHam.cafeNotice.Notice;
import com.cafe.cheezeHam.cafeNotice.NoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class TotalBoardService {
    private final NoticeRepository noticeRepository;
    private final EventRepository eventRepository;
    // 게시글 종류 추가시 레포지토리 추가해야함.

    public Page<TotalBoard> searchTotalBoard(int page, int pageSize, int field, String keyword) {
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(Sort.Order.desc("reg_date")));

        // Keyword 검색 필드에 따른 쿼리 선택
        List<Notice> notices = fetchNotices(field, keyword);
        List<Event> events = fetchEvents(field, keyword);

        List<TotalBoard> combined = Stream.concat(notices.stream(), events.stream())
                .sorted(Comparator.comparing(TotalBoard::getRegDate).reversed())
                .toList();

        // 페이지에 맞는 서브리스트 생성
        int start = Math.min(page * pageSize, combined.size());
        int end = Math.min(start + pageSize, combined.size());
        List<TotalBoard> pagedContent = combined.subList(start, end);

        // 새로운 PageImpl 객체 반환
        return new PageImpl<>(pagedContent, pageable, combined.size());
    }

    private List<Notice> fetchNotices(int field, String keyword) {
        switch (field) {
            case 1: return noticeRepository.findTitleByKeyword(keyword);
            case 2: return noticeRepository.findAuthorByKeyword(keyword);
            case 3: return noticeRepository.findTitleAndContentByKeyword(keyword);
            default: return noticeRepository.findAllByKeyword(keyword);
        }
    }

    private List<Event> fetchEvents(int field, String keyword) {
        switch (field) {
            case 1: return eventRepository.findTitleByKeyword(keyword);
            case 2: return eventRepository.findAuthorByKeyword(keyword);
            case 3: return eventRepository.findTitleAndContentByKeyword(keyword);
            default: return eventRepository.findAllByKeyword(keyword);
        }
    }

    public long getTotalCount() {
        long totalCount = 0;

        totalCount = noticeRepository.count() + eventRepository.count();

        return totalCount;
    }
}
