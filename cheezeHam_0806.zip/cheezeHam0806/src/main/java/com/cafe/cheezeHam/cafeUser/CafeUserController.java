package com.cafe.cheezeHam.cafeUser;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;

@Controller
@RequiredArgsConstructor
@RequestMapping("user")
public class CafeUserController {

    private final CafeUserService cafeUserService;
    private final CafeUserRepository cafeUserRepository;
    private final PasswordEncoder passwordEncoder;

    @GetMapping("/login")
    public String login() {
        return "login_form";
    }

    @GetMapping("/signup")
    public String signup(CafeUserCreateForm cafeUserCreateForm) {return "signup_form";}

    @PostMapping("/signup")
    public String signup(@Valid CafeUserCreateForm cafeUserCreateForm, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "signup_form";
        }
      /*
        boolean error = false;
        String id = cafeUserCreateForm.getId();
        if (id.length() < 3 || id.length() > 25) {
            bindingResult.rejectValue("id", "id.length", "아이디는 3자 이상 25자 이하여야 합니다.");
            error = true;
        }
        String password = cafeUserCreateForm.getPassword();
        if (password.length() < 4 || id.length() > 16){
            bindingResult.rejectValue("password", "password.length", "비밀번호는 4자 이상 16자 이하여야 합니다.");
            error = true;
        }
        String username = cafeUserCreateForm.getUsername();
        if (username.length() < 4 || username.length() > 16){
            bindingResult.rejectValue("username", "username.length", "사용자명은 3자 이상 25자 이하여야 합니다.");
            error = true;
        }

        String email = cafeUserCreateForm.getEmail();
        if (!EmailValid.isValidEmail(email)) {
            bindingResult.rejectValue("email", "emailInvalid", "유효하지 않은 이메일 형식입니다.");
            error = true;
        }
        String birthday = cafeUserCreateForm.getBirthday();
        if (!isValidBirthdays.isValidBirthday(birthday)){
            bindingResult.rejectValue("birthday", "birthdayInvalid", "유효하지 않은 생년월일 형식입니다.");
            error = true;
        }
        String phone = cafeUserCreateForm.getPhone();
        if (!isValidPhoneNumbers.isValidPhoneNumber(phone)){
            bindingResult.rejectValue("phone", "phoneInvalid", "유효하지 않은 전화번호 형식입니다.");
            error = true;
        }

        if(error){
            return "signup_form";
        }


        );*/
        try {
            CafeUser user = getUser(cafeUserCreateForm);
            cafeUserService.create(user);
        }catch(DataIntegrityViolationException e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", "이미 등록된 사용자입니다.");
            return "signup_form";
        }catch(Exception e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", e.getMessage());
            return "signup_form";
        }
        return "redirect:/";
    }

    private static CafeUser getUser(CafeUserCreateForm cafeUserCreateForm) {
        CafeUser user = new CafeUser();
        user.setId(cafeUserCreateForm.getId());
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        user.setPassword(passwordEncoder.encode(cafeUserCreateForm.getPassword()));
        user.setUsername(cafeUserCreateForm.getUsername());
        user.setEmail(cafeUserCreateForm.getEmail());
        user.setGender(cafeUserCreateForm.getGender());
        user.setBirthday(cafeUserCreateForm.getBirthday());
        user.setPhone(cafeUserCreateForm.getPhone());
        user.setRegdate(LocalDateTime.now());
        user.setROLE("USER");
        return user;
    }

    @PostMapping("/check")
    @ResponseBody
    public String checkLogin(HttpServletRequest request) {
        String username = null;
        HttpSession session = request.getSession(false);
        if (session != null) {
            username = (String) session.getAttribute("username");
        }
        return username != null ? username : null;
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/resign")
    public String deleteUser() {return "resign_form";}

    @PreAuthorize("isAuthenticated() and hasRole('USER')")
    @PostMapping("/resign")
    @ResponseBody
    public boolean deleteUser(@RequestParam("password") String password, Principal principal, Model model) {
        CafeUser user = this.cafeUserService.getUser(principal.getName());
        if (passwordEncoder.matches(password, user.getPassword())) {
            this.cafeUserService.deleteCafeUser(user.getId());
            return true;
        }
        return false;
    }

    @PreAuthorize("isAuthenticated() and hasRole('ADMIN')")
    @GetMapping("/list")
    public String userList(Model model, @RequestParam(value="page", defaultValue="0") int page, @RequestParam(value = "keyword", defaultValue = "") String keyword,
                           @RequestParam(value = "pageSize", defaultValue = "15") int pageSize, @RequestParam(value = "field", defaultValue = "전체") String field) {
        Page<CafeUser> paging = this.cafeUserService.getCafeUsers(page, pageSize, field, keyword);

        int block = 10;
        int currentPage = paging.getNumber() + 1;
        int totalPage = paging.getTotalPages();

        int startBlock = (((currentPage - 1) / block) * block) + 1;
        int endBlock = startBlock + block - 1;
        if (endBlock > totalPage) {
            endBlock = totalPage;
        }

        model.addAttribute("startBlock", startBlock);
        model.addAttribute("endBlock", endBlock);
        model.addAttribute("keyword", keyword);
        model.addAttribute("field", field);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("paging", paging);

        return "user_list";
    }
}


