package com.cafe.cheezeHam.cafeWrite;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
@RequestMapping("/cafeWrite")
public class CafeWriteController {

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/writePage")
    public String writePage(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if (username != null) {
                model.addAttribute("username", username);
            }
        }
        return "cafeWrite/main_write_page";
    }
}
