package com.cafe.cheezeHam.cafeUser;

import com.sbb.demo.DataNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CafeUserService {

    private final CafeUserRepository cafeUserRepository;

    public CafeUser create(String id, String username, String password, String email, String birthday, String gender, String phone){
        CafeUser user = new CafeUser();
        user.setId(id);
        user.setUsername(username);
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        user.setPassword(passwordEncoder.encode(password));
        user.setEmail(email);
        user.setBirthday(birthday);
        user.setGender(gender);
        user.setPhone(phone);
        user.setRegdate(LocalDateTime.now());

        this.cafeUserRepository.save(user);
        return user;
    }

    public CafeUser getUser(String id) {
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByid(id);
        if(cafeUser.isPresent()) {
            return cafeUser.get();
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }
}
