package com.cafe.cheezeHam.cafeUser;

import com.sbb.demo.DataNotFoundException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CafeUserService {
    private final EntityManager entityManager;
    private final CafeUserRepository cafeUserRepository;

    public CafeUser create(CafeUser user){
        this.cafeUserRepository.save(user);
        return user;
    }

    public void createADMIN(CafeUser user){this.cafeUserRepository.save(user);}

    public CafeUser getUser(String id) {
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByid(id);
        if(cafeUser.isPresent()) {
            return cafeUser.get();
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }
    public void deleteCafeUser(String id){
        Optional<CafeUser> cafeUser = this.cafeUserRepository.findByid(id);
        if(cafeUser.isPresent()) {
            this.cafeUserRepository.delete(cafeUser.get());
        } else {
            throw new DataNotFoundException("CafeUser NOT FOUND");
        }
    }
}
