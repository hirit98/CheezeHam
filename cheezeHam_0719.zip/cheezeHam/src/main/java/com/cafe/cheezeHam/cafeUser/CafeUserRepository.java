package com.cafe.cheezeHam.cafeUser;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CafeUserRepository extends JpaRepository<CafeUser, Long> {
    Optional<CafeUser> findByno(int no);
    Optional<CafeUser> findByid(String id);
}
