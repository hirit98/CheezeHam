package com.cafe.cheezeHam.cafeBoast;

import com.cafe.cheezeHam.cafeNotice.Notice;
import com.cafe.cheezeHam.cafeNotice.NoticeRepository;
import com.cafe.cheezeHam.cafeUser.CafeUser;
import com.cafe.cheezeHam.cafeUser.CafeUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/boast")
public class BoastController {

    private final BoastCommentRepository boastCommentRepository;
    private final CafeUserService cafeUserService;
    private final BoastService boastService;
    private final BoastRepository boastRepository;
    private final NoticeRepository noticeRepository;


    @Value("${upload.dir}/notice/")
    private String uploadDir;

    private void createUploadDir() {
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/create")
    public String boastCreate(Model model, BoastForm boastForm){
        return "cafeBoast/boast_form";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/create")
    public String boastCreate(Model model, BoastForm boastForm, Principal principal) throws IOException{
        CafeUser user = this.cafeUserService.getUser(principal.getName());


        this.boastService.create(boastForm.getTitle(), boastForm.getContent(), boastForm.getType(), user);
        return "redirect:/boast/list";
    }



    @GetMapping("/list")
    public String boastList(Model model, @RequestParam(value="page", defaultValue="0") int page, @RequestParam(value = "keyword", defaultValue = "") String keyword,
                            @RequestParam(value = "pageSize", defaultValue = "15") int pageSize, @RequestParam(value = "hiddenNotice", defaultValue = "false") boolean hiddenNotice, @RequestParam(value = "field", defaultValue = "0") int field
            ,@RequestParam(value = "sort_value", defaultValue = "") String sort_value){
        List<Notice> importantNotice = noticeRepository.findImportantNoticeList();
        Page<Boast> paging = null;

        if (sort_value.equals("asc")) {
            paging = this.boastService.getBoastsAsc(page, pageSize, field, keyword);
        } else if (sort_value.equals("desc")) {
            paging = this.boastService.getBoastsDesc(page, pageSize, field, keyword);
        } else {
            paging = this.boastService.getBoasts(page, pageSize, field, keyword);
        }


        int block = 10;
        int currentPage = paging.getNumber() + 1;
        int totalPage = paging.getTotalPages();

        int startBlock = (((currentPage - 1) / block) * block) + 1;
        int endBlock = startBlock + block - 1;
        if(endBlock > totalPage) {
            endBlock = totalPage;
        }
        model.addAttribute("field", field);
        model.addAttribute("keyword", keyword);
        model.addAttribute("hiddenNotice", hiddenNotice);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("paging", paging);
        model.addAttribute("importantNotice", importantNotice);
        model.addAttribute("startBlock", startBlock);
        model.addAttribute("endBlock", endBlock);
        model.addAttribute("sort_value", sort_value);

        return "cafeBoast/boast_list";
    }


    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/detail/{no}")
    public String detail(Model model, @PathVariable("no") Integer no, Principal principal) {
        CafeUser user = this.cafeUserService.getUser(principal.getName());
        Boast boast = this.boastService.getBoast(no);
        List<BoastComment> commentList = this.boastService.getBoastComments(no);
        // 이벤트 조회 및 조회수 증가
        if (boast != null) {
            this.boastService.increaseViewCount(no);
        }
        boolean hasPrevious = this.boastService.hasEvent(no - 1);
        boolean hasNext = this.boastService.hasEvent(no + 1);
        boolean isChecked = this.boastService.isChecked(boast, user);

        model.addAttribute("hasPrevious", hasPrevious);
        model.addAttribute("hasNext", hasNext);
        model.addAttribute("isChecked", isChecked);
        model.addAttribute("boast", boast);
        model.addAttribute("commentList", commentList);

        return "cafeBoast/boast_detail";
    }

    @GetMapping("/Comment_ASC_DESC/{no}")
    public String getBoastComment_ASC_DESC(@PathVariable("no") int no, @RequestParam(value = "sort", defaultValue = "desc") String sort, Model model, Principal principal) {
        List<BoastComment> commentList;

        CafeUser user = this.cafeUserService.getUser(principal.getName());
        Boast boast = this.boastService.getBoast(no);

        if (boast != null) {
            this.boastService.increaseViewCount(no);
        }

        if ("asc".equals(sort)) {
            commentList = boastService.findAllByBoastNoOrderByRegDateAsc(no);
        } else {
            commentList = boastService.findAllByBoastNoOrderByRegDateDesc(no);
        }

        boolean hasPrevious = this.boastService.hasEvent(no - 1);
        boolean hasNext = this.boastService.hasEvent(no + 1);
        boolean isChecked = this.boastService.isChecked(boast, user);

        model.addAttribute("hasPrevious", hasPrevious);
        model.addAttribute("hasNext", hasNext);
        model.addAttribute("isChecked", isChecked);
        model.addAttribute("boast", boast);
        model.addAttribute("commentList", commentList);
        return "cafeBoast/boast_detail";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/modify/{no}")
    public String boastModify(BoastForm boastForm, @PathVariable("no") int no, Principal principal){

        Boast boast = this.boastService.getBoast(no);
        if(boast != null) {
            if(!boast.getAuthor().getId().equals(principal.getName())){
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
            }
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정할 게시글이 없습니다.");
        }

        boastForm.setContent(boast.getContent());
        boastForm.setTitle(boast.getTitle());
        return "/cafeBoast/boast_modify_form";
    }
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/modify/{no}")
    public String boastModify(@Valid BoastForm boastForm, Principal principal, @PathVariable("no") int no){
        Boast boast = this.boastService.getBoast(no);

        if(boast != null) {
            if(!boast.getAuthor().getId().equals(principal.getName())){
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
            }
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정할 게시글이 없습니다.");
        }
        this.boastService.boastModify(boast, boastForm.getTitle(), boastForm.getContent(), boastForm.getType());
        return String.format("redirect:/boast/detail/%s", no);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/delete/{no}")
    public String boastDelete(Principal principal, @PathVariable("no") int no) {
        Boast boast = this.boastService.getBoast(no);
        if(boast != null) {
            if(!boast.getAuthor().getId().equals(principal.getName())){
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
            }
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제할 게시글이 없습니다.");
        }
        this.boastService.boastDelete(boast);
        return "redirect:/event/list";
    }
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/comment/create/{no}")
    public String createComment(@PathVariable("no") Integer no,@RequestParam(value="content") String content, Principal principal){
        CafeUser user = this.cafeUserService.getUser(principal.getName());

        Boast boast = this.boastService.getBoast(no);
        this.boastService.createBoastComment(boast, content, user);

        return String.format("redirect:/boast/detail/%s", no);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/comment/modify/{no}")
    public String boastCommentModify(BoastCommentForm boastCommentForm, @PathVariable("no") int no, Principal principal) {
        BoastComment boastComment = this.boastService.getBoastComment(no);
        if (!boastComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }

        boastCommentForm.setContent(boastComment.getContent());
        return "/cafeBoast/reply_modify_form";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/comment/modify/{no}")
    public String boastCommentModify(@Valid BoastCommentForm boastCommentForm, @PathVariable("no") Integer no, Principal principal) {
        BoastComment boastComment = this.boastService.getBoastComment(no);
        if (!boastComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        this.boastService.boastCommentModify(boastComment, boastCommentForm.getContent());
        return String.format("redirect:/boast/detail/%s", boastComment.getBoast().getNo());
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/comment/delete/{no}")
    public String boastCommentDelete(Principal principal, @PathVariable("no") int no) {
        BoastComment boastComment = this.boastService.getBoastComment(no);
        if (!boastComment.getCafeUser().getId().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
        }
        this.boastService.boastCommentDelete(boastComment);
        return String.format("redirect:/boast/detail/%s", boastComment.getBoast().getNo());
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/vote/add/{no}")
    public String addVote(@PathVariable("no") Integer no, Principal principal) {
        Boast boast = this.boastService.getBoast(no);
        CafeUser user = this.cafeUserService.getUser(principal.getName());
        this.boastService.addVote(boast, user);

        return String.format("redirect:/boast/detail/%s", no);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/vote/remove/{no}")
    public String removeVote(@PathVariable("no") Integer no, Principal principal) {
        Boast boast = this.boastService.getBoast(no);
        CafeUser user = this.cafeUserService.getUser(principal.getName());
        this.boastService.removeVote(boast, user);



        return String.format("redirect:/boast/detail/%s", no);
    }

}
