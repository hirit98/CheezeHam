$(document).ready(function() {
    $(".aside_admin_profil").css({ zIndex: "2" });
    $(".aside_tab_btn_cafe_info").css({ fontWeight: "600", color: "black" });

    $(".aside_tab_btn_cafe_info").click(function() {
        $(".aside_admin_profil").css({ zIndex: "2" });
        $(".aside_user_profil").css({ zIndex: "-1" });
        $(".aside_tab_btn_cafe_info").css({ fontWeight: "600", color: "black" });
        $(".aside_tab_btn_my_info").css({ fontWeight: "100", color: "#333" });
    });

    $(".aside_tab_btn_my_info").click(function() {
        $(".aside_admin_profil").css({ zIndex: "-1" });
        $(".aside_user_profil").css({ zIndex: "2" });
        $(".aside_tab_btn_cafe_info").css({ fontWeight: "100", color: "#333" });
        $(".aside_tab_btn_my_info").css({ fontWeight: "600", color: "black" });
    });

    $.ajax({
        type: "GET",
        url: "/total/count",
        success: function(result) {
            if (result !== "" && result.length > 0) {
                $('.aside_total_board_count').text(result);
            } else {
                $('.aside_total_board_count').text(0);
            }
        },
        error: function(xhr, status, error) {
            console.log(xhr.responseText);
        }
    })
    $.ajax({
        type: "GET",
        url: "/total/userCnt",
        success: function(result) {
            if (result !== "" && result.length > 0) {
                $('#visitor').val(result);
            } else {
                $('#visitor').val(0);
            }
        },
        error: function(xhr, status, error) {
            console.log(xhr.responseText);
        }
    })
});
function openNewWindow(url, width, height) {
    var screenWidth = window.innerWidth;
    var screenHeight = window.innerHeight;

    var left = (screenWidth - width) / 2 + window.screenX;
    var top = (screenHeight - height) / 2 + window.screenY;

    window.open(url, '_blank', `width=${width},height=${height},top=${top},left=${left}`);
}