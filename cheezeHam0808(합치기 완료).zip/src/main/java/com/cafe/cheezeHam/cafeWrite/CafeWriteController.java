package com.cafe.cheezeHam.cafeWrite;

import com.cafe.cheezeHam.cafeBoast.BoastService;
import com.cafe.cheezeHam.cafeEvent.EventService;
import com.cafe.cheezeHam.cafeFree.FreeService;
import com.cafe.cheezeHam.cafeNotice.NoticeService;
import com.cafe.cheezeHam.cafeQna.QnaService;
import com.cafe.cheezeHam.cafeUser.CafeUser;
import com.cafe.cheezeHam.cafeUser.CafeUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/cafeWrite")
public class CafeWriteController {

    private final CafeUserService cafeUserService;
    private final BoastService boastService;
    private final FreeService freeService;
    private final QnaService qnaService;

    @Value("${upload.dir}/")
    private String uploadDir;

    private void createUploadDir() {
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/writePage")
    public String writePage(CafeWriteForm cafeWriteForm) {return "cafeWrite/main_write_page";}

    /*@PreAuthorize("isAuthenticated()")
    @PostMapping("/writePage")
    public String writePage(@Valid CafeWriteForm cafeWriteForm, @RequestParam("type") String type, @RequestParam("files") List<MultipartFile> files, Principal principal) {
        CafeUser user = this.cafeUserService.getUser(principal.getName());
        String filePath;
        int max_no;
        if (type.equals("햄스터") || type.equals("고양이")) {
            max_no = this.boastService.getMaxNo() + 1;
            filePath = uploadDir + "/" + max_no;
        } else if (type.equals("자유")) {

        } else if (type.equals("질문답변")) {

        } else if (type.equals("공구")) {

        }

        return "redirect:/";
    }*/
}
