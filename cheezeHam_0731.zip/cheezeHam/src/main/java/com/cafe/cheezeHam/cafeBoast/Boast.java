package com.cafe.cheezeHam.cafeBoast;

import com.cafe.cheezeHam.cafeEvent.EventComment;
import com.cafe.cheezeHam.cafeUser.CafeUser;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Data
@Entity
public class Boast {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no;

    @Column(length = 200)
    private String title;

    @Column(columnDefinition = "LONGTEXT")
    private String content;

    private String type;

    @ManyToOne
    private CafeUser author;

    private LocalDateTime reg_date;

    private LocalDateTime update_date;

    @OneToMany(mappedBy = "boast", cascade = CascadeType.REMOVE)
    private List<BoastComment> commentList;

    @Column(columnDefinition = "INT DEFAULT 0")
    private  int hit;

    private String file_path;

    @ManyToMany
    Set<CafeUser> voter;


}
