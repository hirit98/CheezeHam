package com.cafe.cheezeHam;

import com.cafe.cheezeHam.cafeEvent.EventService;
import com.cafe.cheezeHam.cafeNotice.NoticeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

import static org.assertj.core.api.Fail.fail;

@SpringBootTest
class CheezeHamApplicationTests {

	@Autowired
	private NoticeService noticeService;
	@Autowired
	private EventService eventService;

	@Test
	void contextLoads() {
	}

	@Test
	void testCreateNotice() {
		for(int i = 1; i <= 15; i++) {
			String title = String.format("중요 공지사항[%03d]", i);
			String content = "중요\n중요\n중요\n중요\n중요\n";

			this.noticeService.createImportant(title, content, null);
		}
	}
	@Test
	void testCreateNormalNotice() {
		for(int i = 1; i <= 200; i++) {
			String title = String.format("일반 공지사항[%03d]", i);
			String content = "일반\n일반\n일반\n일반\n일반\n일반\n일반\n";

			this.noticeService.create(title, content, null);
		}
	}
	@Test
	void testCreateEvent() throws IOException {
		for(int i = 1; i <= 200; i++) {
			String title = String.format("중요 이벤트[%03d]", i);
			String content = "이벤트\n이벤트\n이벤트\n이벤트\n이벤트\n";

			/*MultipartFile file = null;*/ // 예시: 실제 파일 객체로 초기화해야 함

			// this.eventService.create() 메서드가 file 파라미터를 요구하는 경우,
			// 실제 파일 객체를 생성하고 초기화해야 합니다.

			// 예시로 MultipartFile을 생성하는 코드
			// MultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "test data".getBytes());

			try {
				eventService.increaseViewCount(i);
				this.eventService.create(title, content, null);
			} catch (IOException e) {
				fail("IOException 발생: " + e.getMessage());
			}
		}
	}


}
