package com.cafe.cheezeHam.cafeUser;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface CafeUserRepository extends JpaRepository<CafeUser, Long> {
    Optional<CafeUser> findByno(int no);
    Optional<CafeUser> findByid(String id);

    @Modifying
    @Transactional
    @Query("DELETE FROM CafeUser u WHERE u.username = :username")
    void deleteByUsername(@Param("username") String username);
}
