package com.cafe.cheezeHam.cafeUser;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
@RequestMapping("user")
public class CafeUserController {

    private final CafeUserService cafeUserService;
    private final CafeUserRepository cafeUserRepository;

    @GetMapping("/login")
    public String login() {
        return "login_form";
    }

    @GetMapping("/signup")
    public String signup(CafeUserCreateForm cafeUserCreateForm) {return "signup_form";}

    @PostMapping("/signup")
    public String signup(@Valid CafeUserCreateForm cafeUserCreateForm, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "signup_form";
        }
      /*
        boolean error = false;
        String id = cafeUserCreateForm.getId();
        if (id.length() < 3 || id.length() > 25) {
            bindingResult.rejectValue("id", "id.length", "아이디는 3자 이상 25자 이하여야 합니다.");
            error = true;
        }
        String password = cafeUserCreateForm.getPassword();
        if (password.length() < 4 || id.length() > 16){
            bindingResult.rejectValue("password", "password.length", "비밀번호는 4자 이상 16자 이하여야 합니다.");
            error = true;
        }
        String username = cafeUserCreateForm.getUsername();
        if (username.length() < 4 || username.length() > 16){
            bindingResult.rejectValue("username", "username.length", "사용자명은 3자 이상 25자 이하여야 합니다.");
            error = true;
        }

        String email = cafeUserCreateForm.getEmail();
        if (!EmailValid.isValidEmail(email)) {
            bindingResult.rejectValue("email", "emailInvalid", "유효하지 않은 이메일 형식입니다.");
            error = true;
        }
        String birthday = cafeUserCreateForm.getBirthday();
        if (!isValidBirthdays.isValidBirthday(birthday)){
            bindingResult.rejectValue("birthday", "birthdayInvalid", "유효하지 않은 생년월일 형식입니다.");
            error = true;
        }
        String phone = cafeUserCreateForm.getPhone();
        if (!isValidPhoneNumbers.isValidPhoneNumber(phone)){
            bindingResult.rejectValue("phone", "phoneInvalid", "유효하지 않은 전화번호 형식입니다.");
            error = true;
        }

        if(error){
            return "signup_form";
        }


        );*/
        try {
            cafeUserService.create(cafeUserCreateForm.getId(), cafeUserCreateForm.getUsername(),
                    cafeUserCreateForm.getPassword(), cafeUserCreateForm.getEmail(),
                    cafeUserCreateForm.getBirthday(), cafeUserCreateForm.getGender(), cafeUserCreateForm.getPhone());
        }catch(DataIntegrityViolationException e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", "이미 등록된 사용자입니다.");
            return "signup_form";
        }catch(Exception e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", e.getMessage());
            return "signup_form";
        }
        return "redirect:/";
    }


    @PostMapping("/check")
    @ResponseBody
    public String checkLogin(HttpServletRequest request) {
        String username = null;
        HttpSession session = request.getSession(false);
        if (session != null) {
            username = (String) session.getAttribute("username");
        }
        return username != null ? username : null;
    }

}
