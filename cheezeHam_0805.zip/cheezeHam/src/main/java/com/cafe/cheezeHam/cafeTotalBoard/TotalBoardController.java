package com.cafe.cheezeHam.cafeTotalBoard;

import com.cafe.cheezeHam.cafeNotice.Notice;
import com.cafe.cheezeHam.cafeNotice.NoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

@Controller
@RequiredArgsConstructor
@RequestMapping("/total")
public class TotalBoardController {

    private final NoticeService noticeService;
    private final TotalBoardService totalBoardService;

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/list")
    public String list(Model model, @RequestParam(value="page", defaultValue="0") int page, @RequestParam(value = "keyword", defaultValue = "") String keyword,
                       @RequestParam(value = "pageSize", defaultValue = "15") int pageSize, @RequestParam(value = "hiddenNotice", defaultValue = "false") boolean hiddenNotice, @RequestParam(value = "field", defaultValue = "0") int field) {
        List<Notice> importantNotice = this.noticeService.getImportantNotices();
        Page<TotalBoard> totalList = this.totalBoardService.searchTotalBoard(page, pageSize, field, keyword);

        int block = 10;
        int currentPage = totalList.getNumber() + 1;
        int totalPage = totalList.getTotalPages();
        int startBlock = (((currentPage - 1) / block) * block) + 1;
        int endBlock = startBlock + block - 1;
        if (endBlock > totalPage) {
            endBlock = totalPage;
        }

        model.addAttribute("field", field);
        model.addAttribute("keyword", keyword);
        model.addAttribute("hiddenNotice", hiddenNotice);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalList", totalList);
        model.addAttribute("importantNotice", importantNotice);
        model.addAttribute("startBlock", startBlock);
        model.addAttribute("endBlock", endBlock);

        return "total/total_list";
    }

    @GetMapping("/count")
    @ResponseBody
    public String getCount() {
        long totalCount = this.totalBoardService.getTotalCount();

        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);

        return nf.format(totalCount);
    }

    @GetMapping("/userCnt")
    @ResponseBody
    public String getUserCnt() {
        long userCount = this.totalBoardService.getTotalUser();
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        return nf.format(userCount);
    }
}
