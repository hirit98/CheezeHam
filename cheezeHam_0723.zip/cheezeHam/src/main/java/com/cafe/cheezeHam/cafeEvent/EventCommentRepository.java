package com.cafe.cheezeHam.cafeEvent;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EventCommentRepository extends JpaRepository<EventComment, Integer> {
/*
    @Query("select ec from EventComment ec where ec.event_no = :no order by ec.regDate desc ")
    List<EventComment> findRecentEventComment(@Param("no") int no);*/

}
